var searchData=
[
  ['pid',['pid',['../class_proceso.html#a49cf2fdd75f27a82a7b013acc91f8baf',1,'Proceso']]],
  ['procspend',['ProcsPend',['../class_usuario.html#a2650633a1af8c44861c18827f0f5976a',1,'Usuario']]],
  ['propuid',['propuid',['../class_proceso.html#ac01822eaa738052c98404d0b40698976',1,'Proceso']]]
];
