var searchData=
[
  ['quitar_5fproceso',['quitar_proceso',['../class_procesador.html#a7eca322e66629007a2c6951f3d694598',1,'Procesador']]],
  ['quitar_5fproceso_5fde_5fprocesador',['quitar_proceso_de_procesador',['../class_cluster.html#ace47d9473f3122ed1bf3813df9d82818',1,'Cluster']]],
  ['quitar_5fus',['quitar_us',['../class_cjt___usuarios.html#a171f245ce23b4c485a618d82ebae8e10',1,'Cjt_Usuarios']]],
  ['quitar_5fusuario',['quitar_usuario',['../class_cluster.html#a2abf6b21e57c99855d1e13eea77ef1ec',1,'Cluster']]]
];
