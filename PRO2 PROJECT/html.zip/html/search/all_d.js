var searchData=
[
  ['vproc',['vproc',['../class_cluster.html#a03d68d53e3b926fd9ee359989833fa9b',1,'Cluster']]],
  ['vuser',['vuser',['../class_cjt___usuarios.html#aed170cd4e45da7e6a8178653dfb232d0',1,'Cjt_Usuarios']]]
];
