var searchData=
[
  ['memfree',['memfree',['../class_procesador.html#ae561e1574f6bfaf1e7dc1da8a514f531',1,'Procesador']]],
  ['memoria',['memoria',['../class_procesador.html#af68811026d52327bbe7ff365f9dadf4a',1,'Procesador']]],
  ['memsize',['memsize',['../class_procesador.html#ad718970bf4e62d2e7ffd3b259460cc40',1,'Procesador']]]
];
