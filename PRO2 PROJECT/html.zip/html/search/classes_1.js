var searchData=
[
  ['procesador',['Procesador',['../class_procesador.html',1,'']]],
  ['proceso',['Proceso',['../class_proceso.html',1,'']]]
];
