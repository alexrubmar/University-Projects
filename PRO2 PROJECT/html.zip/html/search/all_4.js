var searchData=
[
  ['id',['id',['../class_procesador.html#ac389567fa622b2bd70ffbac1bdfdccb9',1,'Procesador']]]
];
