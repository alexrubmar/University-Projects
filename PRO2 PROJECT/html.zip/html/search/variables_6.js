var searchData=
[
  ['uid',['uid',['../class_usuario.html#a192504ac43d52651c55fa0cf08857503',1,'Usuario']]],
  ['umem',['umem',['../class_proceso.html#a4fd0befe22c83c080fab23beff9781be',1,'Proceso']]]
];
