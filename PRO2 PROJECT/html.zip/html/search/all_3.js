var searchData=
[
  ['elegir_5fprocesador',['elegir_procesador',['../class_cluster.html#ab0d2307811c664022c0e5ddc14be4a9e',1,'Cluster']]],
  ['elegir_5fproceso_5fpendiente',['elegir_proceso_pendiente',['../class_cjt___usuarios.html#a02ba7a3bd6f226f52dffb1a97b94a220',1,'Cjt_Usuarios']]],
  ['eliminar_5fproceso_5fmas_5fantiguo',['eliminar_proceso_mas_antiguo',['../class_usuario.html#a1fdab8a74c1a85462353c3b763ab8d75',1,'Usuario']]],
  ['encontrar_5fusuario_5fcon_5fid',['encontrar_usuario_con_id',['../class_cjt___usuarios.html#aa3c58d413fbde1335c1b4a3b5043818c',1,'Cjt_Usuarios']]],
  ['enviar_5fproc_5fa_5fus',['enviar_proc_a_us',['../class_cjt___usuarios.html#a2f355181ddf0dec3912f1327c462db1a',1,'Cjt_Usuarios']]],
  ['enviar_5fproceso_5fa_5fusuario',['enviar_proceso_a_usuario',['../class_cluster.html#a06e6068c2f18dce3724b3854cc327610',1,'Cluster']]],
  ['enviar_5fprocesos_5fa_5fcluster',['enviar_procesos_a_cluster',['../class_cluster.html#abb45ef584abe7bd10a6c0a972dd5f221',1,'Cluster']]],
  ['escribir_5fdatos_5fmemoria',['escribir_datos_memoria',['../class_procesador.html#ab7961a2d7100c482a90482a8a9163610',1,'Procesador']]],
  ['existe_5fusuario',['existe_usuario',['../class_cjt___usuarios.html#a32c6244d6873fabaee24f9dfe7b3fdb4',1,'Cjt_Usuarios']]],
  ['existen_5fprocesos_5fpendientes',['existen_procesos_pendientes',['../class_cjt___usuarios.html#ab72e579cdeb1d7275a0c91467d09e665',1,'Cjt_Usuarios']]],
  ['existen_5fusuarios',['existen_usuarios',['../class_cjt___usuarios.html#a581e1e3f939b8fdbefc03d9a39c359cc',1,'Cjt_Usuarios']]]
];
