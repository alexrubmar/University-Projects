var indexSectionsWithContent =
{
  0: "_aceilmpqrstuv~",
  1: "cpu",
  2: "cpu",
  3: "acelmpqrsu~",
  4: "ailmptuv",
  5: "_",
  6: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "defines",
  6: "Páginas"
};

