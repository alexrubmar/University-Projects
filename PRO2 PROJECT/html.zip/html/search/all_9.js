var searchData=
[
  ['restar_5ftiempo',['restar_tiempo',['../class_proceso.html#abe0922d64c8b7b02c39695261a5726dd',1,'Proceso']]]
];
