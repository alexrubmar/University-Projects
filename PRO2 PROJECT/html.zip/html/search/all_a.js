var searchData=
[
  ['sin_5fprocesos_5fpendientes',['sin_procesos_pendientes',['../class_usuario.html#a5e7c28ff750ced12418dd1c2f26cb6ff',1,'Usuario']]]
];
