var searchData=
[
  ['avanzar_5ftiempo',['avanzar_tiempo',['../class_cluster.html#ae5b15d1951448b995a82b88ce2033867',1,'Cluster']]],
  ['avanzar_5ftmp',['avanzar_tmp',['../class_procesador.html#a1eddb0cb990b9de73d1c87086c04d836',1,'Procesador']]]
];
