var searchData=
[
  ['tej',['tej',['../class_proceso.html#a5a029bee939d49fad91119abc85ff670',1,'Proceso']]]
];
