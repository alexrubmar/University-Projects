var searchData=
[
  ['poner_5fproceso_5fen_5fprocesador',['poner_proceso_en_procesador',['../class_cluster.html#accb0370faec0a1cff4648f89f94fb239',1,'Cluster']]],
  ['poner_5fus',['poner_us',['../class_cjt___usuarios.html#a5cab27c76ecd16150269ddc44f331e92',1,'Cjt_Usuarios']]],
  ['poner_5fusuario',['poner_usuario',['../class_cluster.html#adaecd0742495c7f3c61cb898da59c355',1,'Cluster']]],
  ['proc_5fa_5fus',['proc_a_us',['../class_usuario.html#adcc94224378bb4993b71cf42a7a70c93',1,'Usuario']]],
  ['proc_5fen_5fprocesador',['proc_en_procesador',['../class_procesador.html#aa3554d3e29c3c7f5d87869f6e619ffe8',1,'Procesador']]],
  ['procesador',['Procesador',['../class_procesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador']]],
  ['proceso',['Proceso',['../class_proceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]]
];
